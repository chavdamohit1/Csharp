﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace piramidloop.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            /*1
             * 2 3
             * 6 18 108...N*/
            int i, j;
            //Console.WriteLine("enter any number");
            //int n= convert.ToIn32(console.ReadLine());
            for (i = 1; i <= 5; i++) 
            {
                for (j = 1; j <= i; j++) 
                {
                    Console.Write(j+" ");
                }
                Console.Write("\n");
            }
            Console.WriteLine(" ");

            Console.Read();    
        }
    }
}
