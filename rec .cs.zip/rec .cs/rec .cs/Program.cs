﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rec.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            int[, ,] a = new int[3, 3, 3];
            a[0, 0, 0] = 10;
            a[0, 0, 1] = 35;
            a[0, 0, 2] = 18;
            a[0, 1, 0] = 23;
            a[0, 1, 1] = 45;
            a[0, 1, 2] = 5;
            foreach (int i in a)
            {
                Console.Write(i + " ");
            }
            Console.Read();
        }
    }
}
